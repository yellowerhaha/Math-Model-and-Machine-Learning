

    a=randperm(27);
    for i=1:1:20
        s(i)=a(i);
    end
    s
