y=[33385 28526];
pie(y)
colormap([1,0,0
    0,1,0])
legend('��','Ů')