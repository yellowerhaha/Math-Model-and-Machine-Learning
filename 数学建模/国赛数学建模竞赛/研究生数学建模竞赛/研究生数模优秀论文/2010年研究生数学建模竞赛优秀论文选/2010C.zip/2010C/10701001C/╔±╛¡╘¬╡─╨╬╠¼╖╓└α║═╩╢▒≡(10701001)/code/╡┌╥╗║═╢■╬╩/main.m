% clear,clc
% A = ReadSWC('Motoneuron 1.swc');
% [Surface, Soma_Surface, N_stems, N_bifs, N_branch, N_tips, Type, Diameter,diameter_pow]=FeatureExtraction(A);
result=calculation([1 2 4 5 8 13],'all.xls');